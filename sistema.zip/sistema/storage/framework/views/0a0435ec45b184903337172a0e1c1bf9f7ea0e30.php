<?php $__env->startSection("content"); ?>
    <div class="container-xl d-flex justify-content-center align-items-center ">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <h2 class="page-title">
                <?php echo e(__("Formulário de cadastro de associado")); ?>

            </h2>
        </div>
    </div>
    <div class= "page-body d-flex justify-content-center align-items-center">

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Cadastro</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('cadastros.admin.update',$cadastro->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <h3 class="mb-3">Dados Pessoais</h3>
                        <div class="form-group col-md-4 mb-3 ">
                            <label class="form-label">Data de Associação*</label>
                            <div>
                                <input type="date" class="form-control" aria-describedby="emailHelp"
                                    placeholder="Data de Associação" name="data_associacao" 
                                    value="<?php echo e($cadastro->data_associacao); ?>">
                            </div>
                        </div>
                        <div class="form-group mb-3 ">
                            <label class="form-label">Nome Completo</label>
                            <div>
                                <input type="text" class="form-control" placeholder="Nome" name="nome"
                                    value="<?php echo e($cadastro->nome); ?>" >
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label">Email</label>
                            <div>
                                <input type="email" class="form-control" placeholder="Email" name="email"
                                    value="<?php echo e($cadastro->email); ?>" >
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label">Nome da Mãe</label>
                            <div>
                                <input type="text" class="form-control" placeholder="Mãe" name="mae"
                                    value="<?php echo e($cadastro->mae); ?>" >
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label">Nome do Pai</label>
                            <div>
                                <input type="text" class="form-control" placeholder="Pai" name="pai"
                                    value="<?php echo e($cadastro->pai); ?>" >
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-6 mb-3 ">
                                <label class="form-label">Telefone</label>
                                <div>
                                    <input type="phone" class="form-control" placeholder="(51)xxxx-xxxxx" name="telefone"
                                        value="<?php echo e($cadastro->telefone); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-6 mb-3 ">
                                <label class="form-label">Celular</label>
                                <div>
                                    <input type="phone" class="form-control" placeholder="(51)xxxx-xxxxx" name="celular"
                                        value="<?php echo e($cadastro->celular); ?>" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label class="form-label">CPF</label>
                                    <div>
                                        <input type="text" class="form-control" placeholder="CPF somente números"
                                            name="cpf" value="<?php echo e($cadastro->cpf); ?>" >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label class="form-label">RG</label>
                                    <div>
                                        <input type="text" class="form-control" placeholder="RG somente números" name="rg"
                                            value="<?php echo e($cadastro->rg); ?>" >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label class="form-label">PIS</label>
                                    <div>
                                        <input type="text" class="form-control" placeholder="PIS" name="pis"
                                            value="<?php echo e($cadastro->pis); ?>" >
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Sexo</label>
                               <div>
                                    <select class="form-select" name="sexo" >
                                        <option>Selecione</option>
                                        <option value="masculino" <?php echo e($cadastro->sexo == "masculino" ? "selected" : ""); ?>>
                                            Masculino</option>

                                        <option value="feminino" <?php if($cadastro->sexo == "feminino"): ?> selected <?php endif; ?>>Feminino
                                        </option>
                                    </select>
                                </div> 
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Data de Nascimento</label>
                                <div>
                                    <input type="date" class="form-control" name="data_nascimento"
                                        value="<?php echo e($cadastro->data_nascimento); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Estado Civil</label>
                                <div>
                                    <select class="form-select" name="estado_civil" >
                                        <option value="solteiro(a)" <?php if($cadastro->estado_civil == "solteiro(a)"): ?> selected <?php endif; ?>>
                                            Solteiro(a)</option>
                                        <option value="casado(a)" <?php if($cadastro->estado_civil == "casado(a)"): ?> selected <?php endif; ?>>
                                            Casado(a)</option>
                                        <option value="divorciado(a)" <?php if($cadastro->estado_civil == "divorciado(a)"): ?> selected <?php endif; ?>>
                                            Divorciado(a)</option>
                                        <option value="viuvo(a)" <?php if($cadastro->estado_civil == "viuvo(a)"): ?> selected <?php endif; ?>>Viúvo(a)
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-6">
                                <label class="form-label">Naturalidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Cidade/Estado"
                                        name="naturalidade" value="<?php echo e($cadastro->naturalidade); ?>" >
                                </div>

                            </div>
                            <div class="form-group mb-3 col-md-6">
                                <label class="form-label">Nacionalidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Nacionalidade"
                                        name="nacionalidade" value="Brasileira" value="<?php echo e($cadastro->nacionalidade); ?>"
                                        >
                                </div>
                            </div>
                        </div>
                        <hr class="mt-2">
                        <h3 class="mb-3">Endereço</h3>
                        <div class="row">
                            <div class="form-group mb-3 col-md-8">
                                <label class="form-label">Logradouro</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Avenda/Estrada/Rua"
                                        name="logradouro" value="<?php echo e($endereco->logradouro); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Número</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Número" name="numero"
                                        value="<?php echo e($endereco->numero); ?>" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Complemento</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Complemento" name="complemento"
                                        value="<?php echo e($endereco->complemento); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Bairro</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Bairro" name="bairro"
                                        value="<?php echo e($endereco->bairro); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">CEP</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="CEP - somente números" name="cep"
                                        value="<?php echo e($endereco->cep); ?>" >
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-6">
                                <label class="form-label">Cidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Cidade" name="cidade"
                                        value="<?php echo e($endereco->cidade); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-6">
                                <label class="form-label">Estado</label>
                                <div>
                                    <select class="form-select" name="estado" >
                                        <option value="">Selecione o Estado</option>
                                        <option value="AL" <?php if($endereco->estado == "AL"): ?> selected <?php endif; ?>>Alagoas
                                        </option>
                                        <option value="AC" <?php if($endereco->estado == "AC"): ?> selected <?php endif; ?>>Acre</option>
                                        <option value="AP" <?php if($endereco->estado == "AP"): ?> selected <?php endif; ?>>Amapá</option>
                                        <option value="AM" <?php if($endereco->estado == "AM"): ?> selected <?php endif; ?>>Amazonas
                                        </option>
                                        <option value="BA" <?php if($endereco->estado == "BA"): ?> selected <?php endif; ?>>Bahia
                                        </option>
                                        <option value="CE" <?php if($endereco->estado == "CE"): ?> selected <?php endif; ?>>Ceará
                                        </option>
                                        <option value="DF" <?php if($endereco->estado == "DF"): ?> selected <?php endif; ?>>Distrito
                                            Federal</option>
                                        <option value="ES" <?php if($endereco->estado == "ES"): ?> selected <?php endif; ?>>Espírito
                                            Santo</option>
                                        <option value="GO" <?php if($endereco->estado == "GO"): ?> selected <?php endif; ?>>Goiás
                                        </option>
                                        <option value="MA" <?php if($endereco->estado == "MA"): ?> selected <?php endif; ?>>Maranhão
                                        </option>
                                        <option value="MT" <?php if($endereco->estado == "MT"): ?> selected <?php endif; ?>>Mato Grosso
                                        </option>
                                        <option value="MS" <?php if($endereco->estado == "MS"): ?> selected <?php endif; ?>>Mato Grosso
                                            do Sul</option>
                                        <option value="MG" <?php if($endereco->estado == "MG"): ?> selected <?php endif; ?>>Minas Gerais
                                        </option>
                                        <option value="PA" <?php if($endereco->estado == "PA"): ?> selected <?php endif; ?>>Pará</option>
                                        <option value="PB" <?php if($endereco->estado == "PB"): ?> selected <?php endif; ?>>Paraíba
                                        </option>
                                        <option value="PR" <?php if($endereco->estado == "PR"): ?> selected <?php endif; ?>>Paraná
                                        </option>
                                        <option value="PE" <?php if($endereco->estado == "PE"): ?> selected <?php endif; ?>>Pernambuco
                                        </option>
                                        <option value="PI" <?php if($endereco->estado == "PI"): ?> selected <?php endif; ?>>Piauí
                                        </option>
                                        <option value="RJ" <?php if($endereco->estado == "RJ"): ?> selected <?php endif; ?>>Rio de
                                            Janeiro</option>
                                        <option value="RN" <?php if($endereco->estado == "RN"): ?> selected <?php endif; ?>>Rio Grande do
                                            Norte</option>
                                        <option value="RS" <?php if($endereco->estado == "RS"): ?> selected <?php endif; ?>>Rio Grande do
                                            Sul</option>
                                        <option value="RO" <?php if($endereco->estado == "RO"): ?> selected <?php endif; ?>>Rondônia
                                        </option>
                                        <option value="RR" <?php if($endereco->estado == "RR"): ?> selected <?php endif; ?>>Roraima
                                        </option>
                                        <option value="SC" <?php if($endereco->estado == "SC"): ?> selected <?php endif; ?>>Santa
                                            Catarina</option>
                                        <option value="SP" <?php if($endereco->estado == "SP"): ?> selected <?php endif; ?>>São Paulo
                                        </option>
                                        <option value="SE" <?php if($endereco->estado == "SE"): ?> selected <?php endif; ?>>Sergipe
                                        </option>
                                        <option value="TO" <?php if($endereco->estado == "TO"): ?> selected <?php endif; ?>>Tocantins
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr class="mt-2">
                        <h3 class="mb-3">Dados Funcionais</h3>
                        <div class="row">
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Matrícula Funcional</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Matrícula Funcional Capão da Canoa" name="matricula1"
                                        value="<?php echo e($matriculas->matricula1); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Cidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Cidade" name="cidade1"
                                        value="<?php echo e($matriculas->cidade1); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Data de Admissão </label>
                                <div>
                                    <input type="date" class="form-control" aria-describedby="emailHelp"
                                        placeholder="Data de Adimissão" name="data_admissao1"
                                        value="<?php echo e($matriculas->data_admissao1); ?>" >
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Matrícula Funcional</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Matrícula Funcional Capão da Canoa" name="matricula2"
                                        value="<?php echo e($matriculas->matricula2); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Cidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Função" name="cidade2"
                                        value="<?php echo e($matriculas->cidade2); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Data de Admissão </label>
                                <div>
                                    <input type="date" class="form-control" aria-describedby="emailHelp"
                                        placeholder="Data de Adimissão" name="data_admissao2"
                                        value="<?php echo e($matriculas->data_admissao2); ?>" >
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Matrícula Funcional</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Matrícula Funcional Capão da Canoa" name="matricula3"
                                        value="<?php echo e($matriculas->matricula3); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Cidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Função" name="cidade3"
                                        value="<?php echo e($matriculas->cidade3); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Data de Admissão </label>
                                <div>
                                    <input type="date" class="form-control" aria-describedby="emailHelp"
                                        placeholder="Data de Adimissão" name="data_admissao3"
                                        value="<?php echo e($matriculas->data_admissao3); ?>" >
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Matrícula Funcional</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Matrícula Funcional Capão da Canoa" name="matricula4"
                                        value="<?php echo e($matriculas->matricula4); ?>" >
                                </div>
                            </div>
                            <div class="form-group mb-3 col-md-4">
                                <label class="form-label">Cidade</label>
                                <div>
                                    <input type="text" class="form-control" placeholder="Função" name="cidade4"
                                        value="<?php echo e($matriculas->cidade4); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-4 mb-3 ">
                                <label class="form-label">Data de Admissão </label>
                                <div>
                                    <input type="date" class="form-control" aria-describedby="emailHelp"
                                        placeholder="Data de Adimissão" name="data_admissao4"
                                        value="<?php echo e($matriculas->data_admissao4); ?>" >
                                </div>
                            </div>

                        </div>
                       
                        <div class="row">
                            <div class="form-group col-md-6 mb-3">
                                <label class="form-label">Cargo/Local de Trabalho Capão da Canoa</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Cargo/Local de Trabalho Capão da Canoa" name="cargo_cc"
                                        value="<?php echo e($cadastro->cargo_cc); ?>" >
                                </div>
                            </div>
                            <div class="form-group col-md-6 mb-3">
                                <label class="form-label">Cargo/Local de Trabalho Xangri-lá</label>
                                <div>
                                    <input type="text" class="form-control"
                                        placeholder="Cargo/Local de Trabalho Xangri-lá" name="cargo_xla"
                                        value="<?php echo e($cadastro->cargo_xla); ?>" >
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6 mb-3">
                                    <label class="form-label">Telefone Contato comercial</label>
                                    <div>
                                        <input type="phone" class="form-control" placeholder="(51)xxxx-xxxxx"
                                            name="tel_comercial" value="<?php echo e($cadastro->tel_comercial_cc); ?>" >
                                    </div>
                                </div>
                                <div class="form-group col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <div>
                                        <input type="email" class="form-control" placeholder="E-mail"
                                            name="email_comercial" value="<?php echo e($cadastro->email_comercial_cc); ?>"
                                            >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3 ">
                            <label class="form-label">Função</label>
                            <div>
                                <textarea class="form-control" rows="3" placeholder="Função" name="funcao"
                                    ><?php echo e($cadastro->funcao); ?></textarea>

                            </div>
                        </div>
                        <div class="form-group mb-3 ">
                            <label class="form-label">Área</label>
                            <div>
                                <input type="text" class="form-control" placeholder="Área" name="area"
                                    value="<?php echo e($cadastro->area); ?>" >
                            </div>
                        </div>
                </div>
                <div class="form-footer">
                    <a href="<?php echo e(route("home")); ?>" class="btn btn-primary">Voltar</a>
                  
                    <button type="submit" class="btn btn-success">Editar</button>

                </div>
                </form>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sindmagisterio/public_html/sistema/resources/views/cadastro/associado/edit.blade.php ENDPATH**/ ?>