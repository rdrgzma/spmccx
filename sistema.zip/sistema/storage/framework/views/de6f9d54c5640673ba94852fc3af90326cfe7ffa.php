

<?php $__env->startSection('custom_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">

            <div class="alert alert-success">
                <div class="alert-title">
                    <?php echo e(__('Bem-vindo(a)')); ?> <?php echo e(auth()->user()->name ?? null); ?>

                </div>
                <div class="text-muted">
                    Area restrita do associado. Em breve serão disponbilizadas documentos para downloads, links e
                    notícias do sindicato para os associados.

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistemadoc-master\resources\views/home.blade.php ENDPATH**/ ?>