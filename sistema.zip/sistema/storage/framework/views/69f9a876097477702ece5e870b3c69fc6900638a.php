

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="page-title">
                    <?php echo e(__('Cadastros Inativos')); ?>

                </h2>
                <form action="<?php echo e(route('cadastro.search')); ?>" method="post" class="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('Pesquisar')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                Pesquisar
                            </button>
                        </div>
                    </div>
                </form>
                <a class="btn btn-success" href="<?php echo e(route('lista.index')); ?>">
                    Ver cadastros ativos
                </a>
                <a class="btn btn-danger" href="<?php echo e(route('lista.inativo')); ?>">
                    Listar todos inativos
                </a>
                

            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="table-responsive">
                    <div class="d-flex justify-content-center">
                        <?php echo e($cadastros->links()); ?>

                    </div>
                    <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Nome')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Telefone')); ?></th>
                                <th><?php echo e(__('Data de Associação')); ?></th>
                                <th><?php echo e(__('Ativo')); ?></th>
                                <th><?php echo e(__('Ações')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                                <?php $__empty_1 = true; $__currentLoopData = $cadastros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($cadastro->nome); ?></td>
                                        <td><?php echo e($cadastro->email); ?></td>
                                        <td><?php echo e($cadastro->telefone); ?></td>
                                        <td>
                                            <?php echo e(date('d/m/Y', strtotime($cadastro->data_associacao))); ?>

                                        </td>
                                        <td>
                                           
                                            <button type="button" class="badge <?php if(!$cadastro->isAtivo()): ?> bg-success : bg-danger <?php endif; ?>" data-bs-toggle="modal" data-bs-target="#modalAtive<?php echo e($cadastro->id); ?>">
                                                <?php echo e(__('Não')); ?>

                                            </button>
                                            <div class="modal fade" id="modalAtive<?php echo e($cadastro->id); ?>" tabindex="-1" aria-labelledby="modalAtiveLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                    <h5 class="modal-title" id="modalAtiveLabel">Ativar Associado(a)</h5>
                                                    
                                
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body text-center">
                                                    <p>Deseja ativar o(a) associado(a)?</p>
                                                    <h3 class="fz-10">Nome: <?php echo e($cadastro->nome); ?></h3>
                                                    </div>
                                                    <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                    <a  href="<?php echo e(route('cadastros.admin.ative',$cadastro->id)); ?>" type="button" class="btn btn-primary">Ativar</a>
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
                                           
                                            
                                        </td>
                                
                                        <td>
                                            <a href="<?php echo e(route('cadastros.associado.ver', $cadastro->id)); ?>"
                                                class="btn btn-sm btn-primary"><?php echo e(__('Ver')); ?></a>
                                            <a href="<?php echo e(route('cadastros.admin.edit', $cadastro->id)); ?>" class="btn btn-sm btn-warning"><?php echo e(__('Editar')); ?></a>
                                            <a href="<?php echo e(route('cadastros.admin.dependente', $cadastro->id)); ?>" class="btn btn-sm btn-dark"><?php echo e(__('Dependentes')); ?></a>
                                        </td>

                                    </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">
                                            <h3>Nenhum registro encontrado</h3>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                          
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-center">
                        <?php echo e($cadastros->links()); ?>

                    </div>
                </div> 
            </div>
        
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/fabr8209/sistema.spmccx.com.br/resources/views/cadastro/lista-inativo.blade.php ENDPATH**/ ?>