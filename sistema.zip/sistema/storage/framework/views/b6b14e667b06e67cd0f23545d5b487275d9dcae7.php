

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="page-title">
                    <?php echo e(__('Associados')); ?>

                </h2>
                <form action="<?php echo e(route('cadastro.search')); ?>" method="post" class="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('Pesquisar')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                Pesquisar
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="table-responsive">
                    <table class="table" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Nome')); ?></th>
                                <th><?php echo e(__('RG')); ?></th>
                                <th><?php echo e(__('CPF')); ?></th>
                                <th><?php echo e(__('Telefone')); ?></th>
                                <th><?php echo e(__('E-mail')); ?></th>
                                <th><?php echo e(__('Celular')); ?></th>
                                <th><?php echo e(__('Endereço')); ?></th>
                                <th><?php echo e(__('Número')); ?></th>
                                <th><?php echo e(__('Complemento')); ?></th>
                                <th><?php echo e(__('Bairro')); ?></th>
                                <th><?php echo e(__('Cidade')); ?></th>
                                <th><?php echo e(__('Estado')); ?></th>
                                <th><?php echo e(__('CEP')); ?></th>

                                <th><?php echo e(__('Nome Dependente')); ?></th>
                                <th><?php echo e(__('Data Nascimento')); ?></th>
                                <th><?php echo e(__('Parentesco')); ?></th>

                                <th><?php echo e(__('Nome Dependente')); ?></th>
                                <th><?php echo e(__('Data Nascimento')); ?></th>
                                <th><?php echo e(__('Parentesco')); ?></th>

                                <th><?php echo e(__('Nome Dependente')); ?></th>
                                <th><?php echo e(__('Data Nascimento')); ?></th>
                                <th><?php echo e(__('Parentesco')); ?></th>

                                <th><?php echo e(__('Nome Dependente')); ?></th>
                                <th><?php echo e(__('Data Nascimento')); ?></th>
                                <th><?php echo e(__('Parentesco')); ?></th>

                                <th><?php echo e(__('Nome Dependente')); ?></th>
                                <th><?php echo e(__('Data Nascimento')); ?></th>
                                <th><?php echo e(__('Parentesco')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cadastros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cadastro->nome); ?></td>
                                    <td><?php echo e($cadastro->rg); ?></td>
                                    <td><?php echo e($cadastro->cpf); ?></td>
                                    <td><?php echo e($cadastro->telefone); ?></td>
                                    <td><?php echo e($cadastro->email); ?></td>
                                    <td><?php echo e($cadastro->celular); ?></td>
                                    <td><?php echo e($cadastro->enderecos->logradouro); ?></td>
                                    <td><?php echo e($cadastro->enderecos->numero); ?></td>
                                    <td><?php echo e($cadastro->enderecos->complemento ? $cadastro->enderecos->complemento : ''); ?>

                                    </td>
                                    <td><?php echo e($cadastro->enderecos->bairro); ?></td>
                                    <td><?php echo e($cadastro->enderecos->cidade); ?></td>
                                    <td><?php echo e($cadastro->enderecos->estado); ?></td>
                                    <td><?php echo e($cadastro->enderecos->cep); ?></td>
                                    <?php $__currentLoopData = $cadastro->dependentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($dependente->nome); ?></td>
                                        <td><?php echo e($dependente->data_nascimento); ?></td>
                                        <td><?php echo e($dependente->parentesco); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/TableExport/5.2.0/js/tableexport.min.js"
        integrity="sha512-XmZS54be9JGMZjf+zk61JZaLZyjTRgs41JLSmx5QlIP5F+sSGIyzD2eJyxD4K6kGGr7AsVhaitzZ2WTfzpsQzg=="
        crossorigin="anonymous" referrerpolicy="no-referrer">
        TableExport(document.getElementsById("dataTable"), {
            filename: 'excelfile',
            sheetname: "sheet1"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\rdrgz\projetos\fabricadanet\sistemadoc-master\resources\views/cadastro/export.blade.php ENDPATH**/ ?>