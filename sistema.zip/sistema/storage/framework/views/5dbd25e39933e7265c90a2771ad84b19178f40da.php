<?php $__env->startSection('content'); ?>

    <?php if($dependentes->count() > 0): ?>
        <div class="container-xl d-flex justify-content-center align-items-center ">
            <!-- Page title -->
            <div class="page-header d-print-none">
                <h2 class="page-title">
                    <?php echo e(__('Formulário de cadastro de dependentes')); ?>

                </h2>
            </div>
        </div>
        <div class="page-body d-flex justify-content-center align-items-center ">

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Cadastro</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nome</th>

                                    <th scope="col">Data de Nascimento</th>
                                    <th scope="col">Grau de Parentesco</th>
                                    <th scope="col">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dependentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($dependente->id); ?></th>
                                        <td><?php echo e($dependente->nome); ?></td>

                                        <td><?php echo e($dependente->data_nascimento); ?></td>
                                        <td><?php echo e($dependente->parentesco); ?></td>
                                        <td>

                                            <form action="<?php echo e(route('dependente.destroy', $dependente->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Excluir</button>
                                            </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('dependente.create')); ?>" class=" mt-5 btn btn-success">Cadastrar novo
                            dependente</a>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container-xl d-flex justify-content-center align-items-center ">
            <!-- Page title -->
            <div class="page-header d-print-none">
                <h2 class="page-title">
                    <?php echo e(__('Não há dependentes cadastrados')); ?>

                </h2>
                <a href="<?php echo e(route('dependente.create')); ?>" class=" mt-5 btn btn-success">Cadastrar novo dependente</a>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/fabr8209/sistema.spmccx.com.br/resources/views/cadastro/dependente/show.blade.php ENDPATH**/ ?>