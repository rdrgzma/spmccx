

<?php $__env->startSection('content'); ?>

    <?php if($dependentes->count() > 0): ?>
        <div class="container-xl d-flex justify-content-center align-items-center ">
            <!-- Page title -->
            <div class="page-header d-print-none ">
                <h2 class="page-title ">
                    <?php echo e(__('Cadastro de dependentes')); ?>

                    
                </h2
                <br>
              
              <button type="button" class="btn btn-primary my-2" data-bs-toggle="modal" data-bs-target="#modalCreateDependente">
                    Novo Dependente
                  </button>
                  
                    <br>
              <h3>Associado(a): <?php echo e($cadastro->nome); ?></h3>
            </div>
        </div>
        <div class="page-body d-flex justify-content-center align-items-center ">
                 <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Dependente</h3>

                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                  
                                    <th scope="col">Nome</th>

                                    <th scope="col">Data de Nascimento</th>
                                    <th scope="col">Grau de Parentesco</th>
                                    <th scope="col">Ações</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dependentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($dependente->nome); ?> </td>

                                        <td><?php echo e(date('d/m/Y', strtotime($dependente->data_nascimento))); ?></td>
                                        <td><?php echo e($dependente->parentesco); ?></td>
                                        <td class="d-flex">
                                            
                                                <button type="button" class="btn btn-primary btn-sm mx-3" data-bs-toggle="modal" data-bs-target="#modalUpdateDependente<?php echo e($dependente->id); ?>">Editar</button>
                                            <form action="<?php echo e(route('cadastros.admin.dependente.destroy', $cadastro->id)); ?>" method="POST"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="form-group">                           
                                                                <input type="hidden" class="form-control" id="cadastro_id" name="cadastro_id" value="<?php echo e($cadastro->id); ?>">
                                                                <input type="hidden" class="form-control" id="dependente_id" name="dependente_id" value="<?php echo e($dependente->id); ?>">
                                                            </div>
                                                <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                                            </form>
                                                                                
                                    </tr>

                                       <!-- modal editar dependente -->
                                       <div class="modal fade" id="modalUpdateDependente<?php echo e($dependente->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modalDependenteLabel"
                                            aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalDependenteLabel">Edição Dependente</h5>
                                                        
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('cadastros.admin.dependente.update', $dependente->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="nome">Nome</label>
                                                                <input type="text" class="form-control" id="nome" name="nome"  value="<?php echo e($dependente->nome); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="data_nascimento">Data de Nascimento</label>
                                                                <input type="date" class="form-control" id="data_nascimento" name="data_nascimento"
                                                                    value="<?php echo e($dependente->data_nascimento); ?>">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="parentesco">Grau de Parentesco</label>
                                                                <input type="text" class="form-control" id="parentesco" name="parentesco"
                                                                    value="<?php echo e($dependente->parentesco); ?>">
                                                            </div>
                                                            <div class="form-group">                           
                                                                <input type="hidden" class="form-control" id="cadastro_id" name="cadastro_id" value="<?php echo e($cadastro->id); ?>">
                                                                <input type="hidden" class="form-control" id="dependente_id" name="dependente_id" value="<?php echo e($dependente->id); ?>">
                                                            </div>
                                                            <div class="modal-footer">
                                                               
                                                                <button type="submit" class="btn btn-primary">Salvar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 

                                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-10">
                        <a href="<?php echo e(route('lista.index')); ?>" class=" mt-5 btn btn-dark">Voltar</a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
    <div class="container ">
    <div class="d-flex justify-content-center align-items-center flex-column">
                
                        <!-- Page title -->
                        <div class="page-header d-print-none">
                            <h2 class="page-title">
                                <?php echo e(__('Não há dependentes cadastrados')); ?>

                            </h2>
                            
                            
                        </div>
                        <div class="mt-10 ">
                            
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCreateDependente">
                                Novo Dependente
                            </button>
                        </div>
                </div>
                <div class="mt-10">
                <a href="<?php echo e(route('lista.index')); ?>" class=" mt-5 btn btn-dark">Voltar</a>
                </div>

                
            
        </div>


    </div>
    
        

    <?php endif; ?>

                                    <div class="modal fade" id="modalCreateDependente" tabindex="-1" role="dialog" aria-labelledby="modalDependenteLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalDependenteLabel">Novo Dependente</h5>
                                                        
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('cadastros.admin.dependente.store',$cadastro->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="nome">Nome</label>
                                                                <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="data_nascimento">Data de Nascimento</label>
                                                                <input type="date" class="form-control" id="data_nascimento" name="data_nascimento"
                                                                    placeholder="Data de Nascimento">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="parentesco">Grau de Parentesco</label>
                                                                <input type="text" class="form-control" id="parentesco" name="parentesco"
                                                                    placeholder="Grau de Parentesco">
                                                            </div>
                                                            <div class="form-group">                           
                                                                <input type="hidden" class="form-control" id="cadastro_id" name="cadastro_id" value="<?php echo e($cadastro->id); ?>">
                                                            </div>
                                                            <div class="modal-footer">
                                                             
                                                                <button type="submit" class="btn btn-primary">Salvar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- fim modal -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sindmagisterio/public_html/sistema/resources/views/cadastro/dependente.blade.php ENDPATH**/ ?>