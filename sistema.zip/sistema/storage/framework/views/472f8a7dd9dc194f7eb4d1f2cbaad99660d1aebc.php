<?php $__env->startSection('custom_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
<?php if(auth()->user()->origem == 'site' && auth()->user()->has_cadastro_completo == '0'): ?>
            <div class="alert alert-danger">
                <div class="alert-title">
                    <?php echo e(__('Bem-vindo(a)')); ?> <?php echo e(auth()->user()->name ?? null); ?>

                </div>
                <div class="text-muted">
                    O seu cadastro de associado está INCOMPLETO.
                    Complete o seu cadastro para poder utilizar os benefícios do seu sindicato!
                </div>
            </div>
    <?php else: ?>

            <div class="alert alert-success">
                <div class="alert-title">
                    <?php echo e(__('Bem-vindo(a)')); ?> <?php echo e(auth()->user()->name ?? null); ?>

                </div>
                <div class="text-muted">
                    Area restrita do associado.
                </div>
            </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Herd\Projects\sistema\resources\views/home.blade.php ENDPATH**/ ?>