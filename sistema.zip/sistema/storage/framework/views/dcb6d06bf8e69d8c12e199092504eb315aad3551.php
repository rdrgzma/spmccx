<?php $__env->startSection('content'); ?>
    <form class="card card-md" action="<?php echo e(route('login')); ?>" method="post" autocomplete="off">
        <?php echo csrf_field(); ?>

        <div class="card-body">
            <div class="d-flex justify-content-center mb-3">
            <img src="<?php echo e(asset('img/logo_sindicato_circle.png')); ?>" class="w-25 " alt="<?php echo e(config('app.name')); ?>" class="mb-4">
            </div>
            
            <h2 class="card-title text-center mb-4"><?php echo e(__('Login do Associado(a) ')); ?></h2>

            <div class="mb-3">
                <label class="form-label"><?php echo e(__('Email')); ?></label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e(__('Digite o seu email')); ?>"
                    required autofocus tabindex="1">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label class="form-label">
                    <?php echo e(__('Senha')); ?>


                </label>
                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Digite a sua senha')); ?>" required tabindex="2">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label class="form-check">
                    <input type="checkbox" class="form-check-input" tabindex="3" name="remember" />
                    <span class="form-check-label"><?php echo e(__('Manter conectado neste dispositivo')); ?></span>
                </label>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn btn-primary w-100" tabindex="4"><?php echo e(__('Entrar')); ?></button>
            </div>
        </div>
    </form>

  <!--  <?php if(Route::has('register')): ?>
        <div class="text-center text-muted mt-3">
            <?php echo e(__('Ainda não sou associado(a)')); ?> <a href="<?php echo e(route('register')); ?>"
                tabindex="-1"><?php echo e(__('Cadastrar')); ?></a>
        </div> -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/spmccx/public_html/sistema/resources/views/auth/login.blade.php ENDPATH**/ ?>