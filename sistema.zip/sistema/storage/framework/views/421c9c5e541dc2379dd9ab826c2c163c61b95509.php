<?php $__env->startSection('content'); ?>

    <?php if($dependentes->count() > 0): ?>
        <div class="container-xl d-flex justify-content-center align-items-center ">
            <!-- Page title -->
            <div class="page-header d-print-none">
                <h2 class="page-title">
                    <?php echo e(__('Cadastro de dependentes')); ?>

                </h2>
                <br>
                <h3>Associado(a): <?php echo e($cadastro->nome); ?></h3>
            </div>
        </div>
        <div class="page-body d-flex justify-content-center align-items-center ">

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Dependente</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                  
                                    <th scope="col">Nome</th>

                                    <th scope="col">Data de Nascimento</th>
                                    <th scope="col">Grau de Parentesco</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dependentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($dependente->nome); ?></td>

                                        <td><?php echo e(date('d/m/Y', strtotime($dependente->data_nascimento))); ?></td>
                                        <td><?php echo e($dependente->parentesco); ?></td>
                                                                                
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-10">
                            <a href="<?php echo e(route('convenios.list')); ?>" class=" mt-5 btn btn-dark">Voltar</a>
                            </div>

                       
                        
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container-xl d-flex justify-content-center align-items-center ">
            <!-- Page title -->
            <div class="page-header d-print-none">
                <h2 class="page-title">
                    <?php echo e(__('Não há dependentes cadastrados')); ?>

                </h2>
                
            </div>
            <div class="mt-10">
                <a href="<?php echo e(route('convenios.list')); ?>" class=" mt-5 btn btn-dark">Voltar</a>
                </div>

           
            
        </div>
           
        </div>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/fabr8209/sistema.spmccx.com.br/resources/views/convenio/dependentes.blade.php ENDPATH**/ ?>