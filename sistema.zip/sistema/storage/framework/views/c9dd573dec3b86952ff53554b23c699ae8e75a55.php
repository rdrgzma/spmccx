<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="container-xl">
            <div>
                <button class="btn btn-success mt-3" onclick="downloadPDF()">Download</button>
            </div>
            <!-- Page title -->
            <div class="contentPDF">
                <div class="page-header contentPDF">
                    <h2 class="page-title">
                        <?php echo e(__('Associados')); ?> - Lista Geral
                    </h2>
                </div>
                <div class="page-body">
                    <div class="container-xl">

                        <div class="card ">

                            <div class="table-responsive">
                                <table class="table" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('Nome')); ?></th>
                                            <th><?php echo e(__('CPF')); ?></th>
                                            <th><?php echo e(__('Data de Associação')); ?></th>
                                        	
                                        
                                            <th><?php echo e(__('Assinatura')); ?></th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cadastros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-uppercase"><?php echo e($cadastro->nome); ?></td>
                                                <td><?php echo e($cadastro->cpf); ?></td>
                                                <td>
                                                    <?php echo e(date('d/m/Y', strtotime($cadastro->data_associacao))); ?>

                                                </td>
                                                     
                                                     
                                                     
                                                     
                                                     
                                                          
                                                     
                                                <td>_________________________________</td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <script>
                                function downloadPDF() {
                                    const item = document.querySelector(".contentPDF");

                                    var opt = {
                                        margin: 1,
                                        filename: "listageral.pdf",
                                        html2canvas: {
                                            scale: 2
                                        },
                                        jsPDF: {
                                            unit: "in",
                                            format: "letter",
                                            orientation: "landscape"
                                        },
                                    };

                                    html2pdf().set(opt).from(item).save();
                                }
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Herd\Projects\sistema\resources\views/lista/geral.blade.php ENDPATH**/ ?>