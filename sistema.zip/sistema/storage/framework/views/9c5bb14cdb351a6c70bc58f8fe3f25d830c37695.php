<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="page-title">
                    <?php echo e(__('Convênios')); ?>

                </h2>
                <form action="<?php echo e(route('users.search')); ?>" method="post" class="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('Pesquisar')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                Pesquisar
                            </button>
                        </div>
                    </div>
                </form>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCreateConvenio">
                    Novo Convênio
                  </button>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="table-responsive">
                    <table class="table" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Nome')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Telefone')); ?></th>
                                <th><?php echo e(__('Celular')); ?></th>
                                <th><?php echo e(__('Ativo')); ?></th>
                                <th><?php echo e(__('Ações')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($convenios->count() > 0): ?>
                                <?php $__currentLoopData = $convenios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convenio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($convenio->nome); ?></td>
                                        <td><?php echo e($convenio->email); ?></td>
                                        <td><?php echo e($convenio->telefone); ?></td>
                                        <td><?php echo e($convenio->celular); ?></td>
                                        <td><?php echo e($convenio->ativo); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalViewConvenio">
                                                Ver
                                              </button>

<a href="<?php echo e(route('convenios.editConvenio', $convenio->id)); ?>" class="btn btn-warning">Editar</a>
                                                                                                                                          
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center"><?php echo e(__('Nenhum registro encontrado')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Button trigger modal -->

  
  <!-- Modal -->
  <div class="modal fade" id="modalCreateConvenio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Novo Convênio</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('convenios.store')); ?>" method="post">
            <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label"><?php echo e(__('Nome')); ?></label>
                        <input type="text" class="form-control" id="name" name="nome" placeholder="Nome">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                    </div>        
                    <div class="mb-3">
                        <label for="phone" class="form-label"><?php echo e(__('Telefone')); ?></label>
                        <input type="text" class="form-control" id="phone" name="telefone" placeholder="Telefone">
                    </div>
                    <div class="mb-3">
                        <label for="cellphone" class="form-label"><?php echo e(__('Celular')); ?></label>
                        <input type="text" class="form-control" id="celular" name="celular"
                            placeholder="Celular">
                    </div>
                    <div class="mb-3">
                        <label for="cpf" class="form-label"><?php echo e(__('CPF')); ?></label>
                        <input type="text" class="form-control" id="cpf" name="cpf" placeholder="CPF">
                    </div>  
                    <div class="mb-3">
                        <label for="cnpj" class="form-label"><?php echo e(__('CNPJ')); ?></label>
                        <input type="text" class="form-control" id="cnpj" name="cnpj" placeholder="CNPJ">
                    </div>
                    <div class="mb-3">
                        <label for="active" class="form-label"><?php echo e(__('Ativo')); ?></label>
                        <select class="form-select" id="active" name="ativo">
                            <option value="sim">Sim</option>
                            <option value="nao">Não</option>
                        </select>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <input type="submit" class="btn btn-primary" value="Salvar">
            </div>
    </form>
      </div>
    </div>
  </div>

  <!-- Modal ver Convênio -->

    <div class="modal fade" id="modalViewConvenio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Convênio</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Nome: <?php echo e($convenio->nome); ?>

                <br>
                Email: <?php echo e($convenio->email); ?>

                <br>
                Telefone: <?php echo e($convenio->telefone); ?>

                <br>
                Celular: <?php echo e($convenio->celular); ?>

                <br>
                Ativo: <?php echo e($convenio->ativo); ?>

            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
             <input type="submit" class="btn btn-primary" value="Salvar">
       
            </div>
        </form>
          </div>
        </div>
      </div>



      
            

                            
    </div>
    </div>
  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/fabr8209/sistema.spmccx.com.br/resources/views/convenio/index.blade.php ENDPATH**/ ?>