

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="page-title">
                    <?php echo e(__('Associados')); ?>

                </h2>
                <form action="<?php echo e(route('cadastro.search')); ?>" method="post" class="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('Pesquisar')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                Pesquisar
                            </button>
                        </div>
                    </div>
                </form>
                <a class="btn btn-success" href="<?php echo e(route('lista.index')); ?>">
                    Listar todos
                </a>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="table-responsive">
                    <table class="table" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Nome')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Telefone')); ?></th>
                                <th><?php echo e(__('Data de Associação')); ?></th>
                                <th><?php echo e(__('Cadastro')); ?></th>
                                <th><?php echo e(__('Ações')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cadastros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cadastro->nome); ?></td>
                                    <td><?php echo e($cadastro->email); ?></td>
                                    <td><?php echo e($cadastro->telefone); ?></td>
                                    <td>
                                        <?php echo e(date('d/m/Y', strtotime($cadastro->data_associacao))); ?>

                                    </td>
                                    <td><?php echo e($cadastro->status); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('cadastros.associado.ver', $cadastro->id)); ?>"
                                            class="btn btn-sm btn-primary"><?php echo e(__('Ver')); ?></a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php if($cadastros->count() > 25): ?>
                    <div class="card-footer pb-0">
                        <?php echo e($cadastro->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\rdrgz\projetos\fabricadanet\sistemadoc-master\resources\views/cadastro/lista.blade.php ENDPATH**/ ?>