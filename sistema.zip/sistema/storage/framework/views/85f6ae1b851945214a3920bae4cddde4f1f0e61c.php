

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="page-title">
                    <?php echo e(__('Associados')); ?>

                </h2>
                <form action="<?php echo e(route('convenios.search')); ?>" method="post" class="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="<?php echo e(__('Pesquisar')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                Pesquisar
                            </button>
                        </div>
                    </div>
                </form>
                <a class="btn btn-success" href="<?php echo e(route('convenios.list')); ?>">
                    Listar todos
                </a>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="card
            <?php if(isset($cadastros)): ?>
                <div class="table-responsive">
                    <div class="d-flex justify-content-center">
                        <?php echo e($cadastros->links()); ?>

                    </div>
                    <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
               <div class="table-responsive">
                    <table class="table" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Nome')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Telefone')); ?></th>
                                <th><?php echo e(__('Ativo')); ?></th>
                                <th><?php echo e(__('Ações')); ?></th>
                            </tr>
                        </thead>   
                        <tbody>
                            <?php if($cadastros->count() > 0): ?>
                                    <?php $__currentLoopData = $cadastros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cadastro->nome); ?></td>
                                        <td><?php echo e($cadastro->email); ?></td>
                                        <td><?php echo e($cadastro->telefone); ?></td>       
                                        <td><?php echo e($cadastro->ativo); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('convenios.dependentes', $cadastro->id)); ?>" class="btn btn-sm btn-dark"><?php echo e(__('Dependentes')); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhum registro encontrado</td>
                                </tr>
                            <?php endif; ?>
                            
                            
                            </tbody>
                    </table>
                </div>
             

            </div>
            <div class="modal fade" id="modalViewAssociado" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Dependentes</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        
                        <table>
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Parentesco</th>
                                    <th>Data de Nascimento</th>          
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dependentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($cadastro)): ?>
                                    <?php if($item->cadastro_id == $cadastro->id): ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td><?php echo e($item->nome); ?></td>
                                        <td><?php echo e($item->parentesco); ?></td>
                                        <td><?php echo e($item->data_nascimento); ?></td>
                                    </tr>  
                                    <?php endif; ?>                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>


                      
                     
                    </div>
        
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                     <input type="submit" class="btn btn-primary" value="Salvar">
               
                    </div
                    <?php endif; ?>
                    <?php if(isset($cadastros)): ?>
                    <h3> Nenhum associado encontrado!</h3>
                    <?php endif; ?>
                    
                      <div class="d-flex justify-content-center">
                <?php echo e($cadastros->links()); ?>

            </div>
            
        </div>
    </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/fabr8209/sistema.spmccx.com.br/resources/views/convenio/listar.blade.php ENDPATH**/ ?>