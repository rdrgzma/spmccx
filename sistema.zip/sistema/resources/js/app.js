
require('@tabler/core/src/js/tabler.js');

require('./bootstrap');


